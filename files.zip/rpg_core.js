/* =========================================================================
   rpg_core.js — MODULE 1: LÕI RPG (Battle Royale ĐRL)
   Nạp TRƯỚC script.js (index.html: dialogue.js, map.js, rpg_core.js, script.js).
   Không phụ thuộc DOM, không đụng vào S của script.js -> xuất ra window.RPG.

   Nội dung:
     1) CFG            — mọi hằng số cân bằng (sửa số ở đây là đủ)
     2) CLASSES        — 5 Class, chỉ số gốc, kỹ năng Lv1/3/5 + Ultimate (dạng DỮ LIỆU;
                         module 2 "combat engine" sẽ đọc `effects` để thực thi)
     3) CLASS_QUIZ     — bộ trắc nghiệm chọn Class
     4) ITEMS/RECIPES  — vật phẩm hỗ trợ combat + công thức chế tạo
     5) Fighter / EXP / Level (tối đa Lv5)
     6) ĐRL            — cướp/trừ 50%, loại người thấp nhất, TIU phạt
     7) Trust / Party  — nói chuyện, mời vào đội
     8) Mô phỏng NPC đánh nhau ngầm, serialize/load
   ========================================================================= */
(function (global) {
  "use strict";

  /* ============================ 1) CẤU HÌNH ============================ */
  const CFG = {
    MAX_LEVEL: 5,
    EXP_TABLE: [0, 0, 30, 80, 150, 220], // EXP_TABLE[lv] = EXP tích lũy cần để đạt lv
    GROWTH_LEVELS: [2, 4],               // Lv không có skill -> cộng chỉ số
    GROWTH_PCT: 0.10,                    // +10% chỉ số gốc mỗi mốc
    ULT_UNLOCK_LEVEL: 1,                 // Ultimate dùng được từ Lv1 (chỉ cần đầy Nộ)

    EXP_BASE_WIN: 20,
    EXP_PER_ENEMY_LEVEL: 10,
    EXP_UNDERDOG_BONUS: 0.5,             // thắng đối thủ Lv cao hơn: +50%

    START_DRL: 30,
    DRL_STEAL_PCT: 0.25,                 // THẮNG: cướp 25% ĐRL của kẻ thua
    DRL_PLAYER_LOSS_PCT: 0.25,            // người chơi THUA: bị trừ 25% ĐRL (NPC đánh nhau với nhau: kẻ thua mất đúng phần bị cướp)
    TIU_PENALTY: 5,                      // The TIU bắt được người chơi (chỉ Chapter 1)

    BATTLE_MINUTES: 60,                  // 1 trận đấu tốn 60 phút đồng hồ trong game
    REGEN_PER_HOUR: 0.10,                // hồi dần 10% HP tối đa mỗi giờ game (ngoài trận)
    REST_HEAL_PCT: 0.35,                 // "Nghỉ ngơi 1 giờ" ở Căn tin: +35% HP tối đa

    RAGE_MAX: 100,
    RAGE_ON_ATTACK: 25,
    RAGE_ON_SKILL: 35,

    LAPEACE_NEEDED: 3,                   // tổng số loại Mảnh La Peace (mỗi loại cho 1 sức mạnh riêng, xem LAPEACE_PIECES)
    LAPEACE_DEADLINE_MIN: 180,           // 03:00 — mảnh chưa ai nhặt sẽ rơi vào tay 1 đối thủ ngẫu nhiên
    MANA_TRANSFER_PCT: 0.5,              // Mana Transfer: sau khi tung Ultimate được hồi lại 50% thanh Nộ
    DIE_TWICE_HP_PCT: 0.5,               // Die Twice: hồi sinh với 50% HP tối đa (1 lần mỗi trận)

    TRUST_MAX: 3,
    RECRUIT_TRUST: 2,
    PARTY_MAX_ALLIES: 1,                 // tối đa 2 đồng đội + người chơi = 3 người (giống PARTY_DEF cũ)

    // hồi chiêu đề xuất (spec chưa nêu) — Ultimate không dùng CD mà dùng Nộ đầy
    SKILL_CD: { 1: 2, 3: 3, 5: 4 },

    // ---- Thể lực khi di chuyển giữa các khu vực ----
    STAMINA_MAX: 100,
    STAMINA_MOVE_COST: 20,               // mỗi lần đổi khu vực (5 lần thì cạn)
    STAMINA_REGEN_PER_MIN: 0.4,          // hồi dần theo phút game (24/giờ)
    STAMINA_REST_GAIN: 50,               // "Nghỉ ngơi 1 giờ" ở Căn tin
    AMBUSH_REARM: 40,                    // (cũ) không còn dùng
    EXHAUST_HP_PCT: 0.5,                 // đi khi thiếu thể lực -> bị đánh lén: vào trận chỉ còn tối đa 50% HP, mọi skill đang hồi chiêu

    // ---- The TIU là boss: bị bắt = đấu với TIU (hiện thân của mọi skill) ----
    TIU_TAINTED_WIN: 8,                  // thắng TIU: +8 ĐRL vấy bẩn
    TIU_HP_BASE: 190, TIU_HP_PER_LV: 42, // HP TIU = base + perLv * Lv người chơi
    TIU_ATK_BASE: 13, TIU_ATK_PER_LV: 1.5,
    TIU_DEF_BASE: 12, TIU_DEF_PER_LV: 2,
    TIU_SPD: 45,

    // ---- Đồng đội bỏ đội nếu người chơi không kiếm thêm ĐRL ----
    PARTY_CHECK_MIN: 120,                // cứ mỗi 120 phút game kiểm tra 1 lần
    PARTY_MIN_GAIN: 5,                   // phải kiếm thêm ít nhất 5 ĐRL trong mỗi kỳ
    PARTY_LEAVE_AMBUSH: 0.25,            // 25% đồng đội rời đội sẽ đánh lén người chơi

    // ---- Hệ thuộc tính & chí mạng ----
    WEAK_MULT: 1.3,                      // đánh trúng YẾU ĐIỂM: x1.3 sát thương, +WEAK_RAGE Nộ cho người đánh
    RESIST_MULT: 0.7,                    // đánh vào hệ KHÁNG: x0.7
    WEAK_RAGE: 10,
    CRIT_BASE: 0.05, CRIT_PER_SPD: 0.0015, CRIT_WEAK_BONUS: 0.15, CRIT_CAP: 0.60,   // tỉ lệ chí mạng = base + SPD*perSpd (+15% nếu trúng yếu điểm)
    CRIT_MULT: 1.5
  };

  /* ------------------------- HỆ THUỘC TÍNH ------------------------- */
  const ELEMENTS = {
    slash:   { name: "Chém",      icon: "⚔️" },
    fire:    { name: "Hỏa",       icon: "🔥" },
    ice:     { name: "Băng",      icon: "❄️" },
    thunder: { name: "Lôi",       icon: "⚡" },
    poison:  { name: "Độc",       icon: "☠️" },
    void:    { name: "Hư Không",  icon: "🌀" }
  };
  /* Vòng khắc chế: Chém > Pháp sư · Lôi > Đấu sĩ · Băng > Sát thủ · Độc > Triệu hồi · Hỏa > Hộ tế · Hư Không > The TIU */
  const AFFINITY = {
    fighter:  { weak: "thunder", resist: "slash",   basic: "slash" },
    assassin: { weak: "ice",     resist: "void",    basic: "slash" },
    mage:     { weak: "slash",   resist: "thunder", basic: "fire" },
    healer:   { weak: "fire",    resist: "poison",  basic: "poison" },
    summoner: { weak: "poison",  resist: "fire",    basic: "void" }
  };
  const SKILL_ELEMENT = {
    // skill gây sát thương -> hệ
    fireball: "fire", iceWall: "ice", toxicBlast: "poison", finisher: "slash",
    // Ultimate
    lastStopper: "slash", perfectKill: "slash", thunder: "thunder", bitterMedicine: "poison", voidSummon: "void"
  };
  function affinityOf(f) {
    if (!f) return {};
    if (f.tiu) return { weak: "void", resist: null, basic: "void" };
    return AFFINITY[f.classId] || {};
  }
  function basicElement(f) { return affinityOf(f).basic || null; }
  function elementLabel(key) { const e = ELEMENTS[key]; return e ? e.icon + " " + e.name : "—"; }

  /* ============================ 2) CLASS ============================ */
  // effects: danh sách mô tả hiệu ứng cho combat engine.
  //   power = hệ số sát thương nhân với ATK (đề xuất, chỉnh tuỳ ý)
  const CLASSES = {
    fighter: {
      id: "fighter", name: "Đấu Sĩ", icon: "🛡️",
      base: { hp: 100, atk: 20, def: 60, spd: 20 },
      passive: { id: "ironWill", name: "Ý chí thép", rageOnHit: 35,
                 desc: "Mỗi lần bị tấn công trúng, tích thêm 35 Nộ." },
      skills: [
        { id: "guard", lvl: 1, name: "Rho Aias", target: "self",
          desc: "Tăng 40 DEF trong 2 turn.",
          effects: [{ type: "buff", stat: "def", amount: 40, turns: 2 }] },
        { id: "counter", lvl: 3, name: "Phản đòn", target: "self",
          desc: "Miễn nhiễm sát thương 1 turn, phản lại 50% sát thương địch vừa gây ra.",
          effects: [{ type: "immune", turns: 1 }, { type: "reflect", pct: 0.5, turns: 1 }] },
        { id: "lastStand", lvl: 5, name: "Cửu mệnh", target: "self",
          desc: "Xóa mọi debuff, tăng 20 ATK và 20 DEF trong 3 turn.",
          effects: [{ type: "cleanse" },
                    { type: "buff", stat: "atk", amount: 20, turns: 3 },
                    { type: "buff", stat: "def", amount: 20, turns: 3 }] }
      ],
      ultimate: { id: "lastStopper", name: "Chốt chặn cuối cùng", target: "aoe",
        desc: "Mất 25% HP hiện tại, gây sát thương cực lớn lên toàn bộ kẻ địch.",
        effects: [{ type: "selfCostCurHpPct", pct: 0.25 }, { type: "damage", power: 4.5 }] }
    },

    assassin: {
      id: "assassin", name: "Sát Thủ", icon: "🗡️",
      base: { hp: 60, atk: 70, def: 10, spd: 60 },
      skills: [
        { id: "nimble", lvl: 1, name: "Trace on ", target: "self",
          desc: "Tăng 40 ATK trong 2 turn.",
          effects: [{ type: "buff", stat: "atk", amount: 40, turns: 2 }] },
        { id: "finisher", lvl: 3, name: "Xạ Sát Bách Thủ", target: "single",
          desc: "Gây sát thương lớn lên 1 kẻ địch.",
          effects: [{ type: "damage", power: 1.3 }] },
        { id: "instinct", lvl: 5, name: "Hòa vào màn đêm", target: "self",
          desc: "Tàng hình 2 turn (không thể bị chỉ định, chỉ nhận sát thương từ skill AoE).",
          effects: [{ type: "stealth", turns: 2 }] }
      ],
      ultimate: { id: "perfectKill", name: "Vô hạn kiếm giới", target: "single",
        desc: "Gây sát thương cực lớn, 30% tỉ lệ kết liễu (Execute) mục tiêu ngay lập tức.",
        effects: [{ type: "damage", power: 2.4 }, { type: "execute", chance: 0.3 }] }
    },

    mage: {
      id: "mage", name: "Pháp Sư", icon: "🔮",
      base: { hp: 80, atk: 50, def: 20, spd: 50 },
      skills: [
        { id: "fireball", lvl: 1, name: "Hỏa cầu thuật", target: "aoe",
          desc: "Gây sát thương, 30% tỉ lệ gây hiệu ứng Cháy (DoT).",
          effects: [{ type: "damage", power: 0.85 },
                    { type: "status", status: "burn", chance: 0.3, turns: 3, dotPower: 0.3 }] },
        { id: "iceWall", lvl: 3, name: "Băng phong vạn dặm", target: "aoe",
          desc: "Giảm SPD kẻ địch, 50% tỉ lệ Đóng băng. Kẻ địch bị Đóng băng nhận thêm 50% damage.",
          effects: [{ type: "damage", power: 0.8 },
                    { type: "debuff", stat: "spd", amount: 20, turns: 2 },
                    { type: "status", status: "freeze", chance: 0.5, turns: 2, dmgTakenMult: 1.5 }] },
        { id: "windSpirit", lvl: 5, name: "Phong khởi", target: "aoe",
          desc: "Triệu hồi Tinh linh gió: đánh thường +25% sức mạnh, +50% SPD. Cast lần 2: Tinh linh phát nổ AoE theo số turn đã tồn tại.",
          effects: [{ type: "summon", summon: "windSpirit", atkMult: 1.25, spdMult: 1.5 },
                    { type: "recastExplode", powerPerTurn: 0.5 }] }
      ],
      ultimate: { id: "thunder", name: "Lôi thần giáng thế", target: "aoe",
        desc: "Sát thương lớn, 50% tỉ lệ gây Tê liệt (bỏ qua turn).",
        effects: [{ type: "damage", power: 2.0 },
                  { type: "status", status: "paralyze", chance: 0.5, turns: 1 }] }
    },

    healer: {
      id: "healer", name: "Dược Sư", icon: "🧪",
      base: { hp: 120, atk: 20, def: 50, spd: 30 },
      skills: [
        { id: "poison", lvl: 1, name: "Độc dược", target: "single",
          desc: "Gây độc (DoT), cộng dồn tối đa 3 stack.",
          effects: [{ type: "poisonStack", amount: 1, max: 3, dotPower: 0.5 }] },
        { id: "blessing", lvl: 3, name: "Phước lành dược sư", target: "self",
          desc: "Hồi 25% HP tối đa.",
          effects: [{ type: "healPct", pct: 0.25 }] },
        { id: "toxicBlast", lvl: 5, name: "Vụ nổ độc hại", target: "aoe",
          desc: "Gây sát thương Độc lên toàn bộ mục tiêu.",
          effects: [{ type: "poisonDamage", powerPerStack: 0.6, baseStacks: 1 }] }
      ],
      ultimate: { id: "bitterMedicine", name: "Thuốc đắng giã tật", target: "aoe",
        desc: "Gây sát thương tức thì theo số stack độc hiện có, sau đó nhân đôi stack độc trên kẻ địch.",
        effects: [{ type: "poisonDamage", powerPerStack: 1.2, baseStacks: 0 }, { type: "doublePoisonStacks" }] }
    },

    summoner: {
      id: "summoner", name: "Triệu Hồi Sư", icon: "👁️",
      base: { hp: 110, atk: 30, def: 40, spd: 20 },
      skills: [
        { id: "summonSword", lvl: 1, name: "Triệu hồi Ma Kiếm", target: "summon",
          desc: "Tạo đồng minh đánh kế tiếp, gây sát thương = 50% ATK Triệu Hồi Sư.",
          effects: [{ type: "summon", summon: "sword", atkPct: 0.5 }] },
        { id: "summonGuard", lvl: 3, name: "Triệu hồi Hộ Vệ", target: "summon",
          desc: "Tạo đồng minh có Taunt. Nếu đang có Ma Kiếm: hợp thể thành Ma Kiếm Sĩ (sát thương 100%, có Taunt).",
          effects: [{ type: "summon", summon: "guard", taunt: true },
                    { type: "fuse", from: ["sword", "guard"], into: "swordsman", atkPct: 1.0 }] },
        { id: "manaTransfer", lvl: 5, name: "Truyền Mana", target: "summon",
          desc: "Hồi máu cho các vật triệu hồi.",
          effects: [{ type: "healSummons", pct: 0.4 }] }
      ],
      ultimate: { id: "voidSummon", name: "Triệu hồi Hư Không", target: "summon",
        desc: "Ma Kiếm → Hỗn Mang Kiếm (+75% DMG); Hộ Vệ → Giáp Hư Không (+50% HP); Ma Kiếm Sĩ → Hỗn Mang Kiếm Sĩ (có thanh Nộ và dùng Nộ như Đấu Sĩ).",
        effects: [{ type: "upgradeSummon", sword: { dmgMult: 1.75 }, guard: { hpMult: 1.5 },
                    swordsman: { rage: true } }] }
    }
  };
  const CLASS_IDS = Object.keys(CLASSES);

  /* ============================ 3) TRẮC NGHIỆM CLASS ============================ */
  // Mỗi đáp án cộng 1 điểm cho class tương ứng. UI nên xáo trộn thứ tự đáp án.
  const CLASS_QUIZ = [
    { q: "Deadline còn 3 tiếng nữa, bạn làm gì?",
      a: [{ t: "Thức trắng cày một mạch tới sáng", c: "fighter" },
          { t: "Tập trung làm gọn trong đúng 1 tiếng", c: "assassin" },
          { t: "Nghĩ ra một giải pháp thần kỳ chưa ai dùng", c: "mage" },
          { t: "Pha cà phê, chia bánh cho cả nhóm cùng cố", c: "healer" },
          { t: "Giao việc cho cả hội và điều phối", c: "summoner" }] },
    { q: "Bạn hay ngồi ở đâu trong giảng đường?",
      a: [{ t: "Hàng đầu, chắc chắn và vững vàng", c: "fighter" },
          { t: "Cuối lớp, lặng lẽ quan sát", c: "assassin" },
          { t: "Cạnh cửa sổ, thả hồn theo mây", c: "mage" },
          { t: "Cạnh bạn đang mệt để chăm sóc", c: "healer" },
          { t: "Giữa đám bạn thân", c: "summoner" }] },
    { q: "Bị trừ ĐRL oan, bạn phản ứng thế nào?",
      a: [{ t: "Cãi tới cùng, không lùi bước", c: "fighter" },
          { t: "Âm thầm tìm cách lấy lại đúng lúc", c: "assassin" },
          { t: "Dùng lý lẽ sắc bén thuyết phục", c: "mage" },
          { t: "Thông cảm, nói chuyện nhẹ nhàng", c: "healer" },
          { t: "Rủ cả hội đi giải quyết cùng", c: "summoner" }] },
    { q: "Trong balo của bạn luôn có gì?",
      a: [{ t: "Chai nước lớn, sẵn sàng chịu đựng", c: "fighter" },
          { t: "Đúng một cây bút, gọn nhẹ", c: "assassin" },
          { t: "Sổ ghi đầy công thức và hình vẽ", c: "mage" },
          { t: "Túi thuốc, bánh kẹo để chia bạn", c: "healer" },
          { t: "Danh bạ đầy người sẵn sàng giúp", c: "summoner" }] },
    { q: "Bạn muốn nổi bật trong trận chiến này nhờ điều gì?",
      a: [{ t: "Đứng vững tới người cuối cùng", c: "fighter" },
          { t: "Một đòn chí mạng bất ngờ", c: "assassin" },
          { t: "Sức mạnh quét sạch diện rộng", c: "mage" },
          { t: "Làm đối thủ kiệt sức dần", c: "healer" },
          { t: "Điều khiển đồng đội của riêng mình", c: "summoner" }] }
  ];

  /* ============================ 4) VẬT PHẨM HỖ TRỢ COMBAT ============================ */
  // usable: nơi dùng được. target: 'self' | 'enemy' | 'allEnemies' | 'room' | 'none'
  const ITEMS = {
    bimbim:  { name: "Bim Bim", icon: "🍟", usable: ["combat", "map"], target: "self", price: 8,
               desc: "Hồi 30% HP tối đa.",
               effects: [{ type: "healPct", pct: 0.30 }] },
    water:   { name: "Nước tăng lực", icon: "🥤", usable: ["combat"], target: "self", price: 6,
               desc: "+25 Nộ và +20 SPD trong 2 turn.",
               effects: [{ type: "rage", amount: 25 }, { type: "buff", stat: "spd", amount: 20, turns: 2 }] },
    camera:  { name: "Máy quay soi", icon: "📷", usable: ["map", "combat"], target: "enemy", price: null,
               desc: "Xem Class, Lv, HP, ĐRL, Nộ và skill sắp dùng của đối thủ.",
               effects: [{ type: "scout" }] },
    flash:   { name: "Đèn flash", icon: "💡", usable: ["combat"], target: "enemy", price: null,
               desc: "Làm 1 mục tiêu choáng, mất 1 turn.",
               effects: [{ type: "status", status: "stun", chance: 1, turns: 1 }] },
    grenade: { name: "Lựu đạn điện", icon: "⚡", usable: ["combat"], target: "allEnemies", price: null,
               desc: "Gây 25 sát thương cố định (bỏ qua DEF) lên toàn bộ kẻ địch.",
               effects: [{ type: "trueDamage", amount: 25 }] },
    trap:    { name: "Bẫy gài", icon: "🪤", usable: ["map"], target: "room", price: null,
               desc: "Đặt ở phòng hiện tại. Ai bước vào bị trừ 20% HP và mất lượt đầu của trận kế tiếp.",
               effects: [{ type: "placeTrap", hpPct: 0.2, skipFirstTurn: true, durationMin: 120 }] },
    antidote:{ name: "Thuốc giải", icon: "💊", usable: ["combat", "map"], target: "self", price: 10,
               desc: "Xóa Cháy, Độc, Đóng băng, Tê liệt.",
               effects: [{ type: "cleanse", only: ["burn", "poison", "freeze", "paralyze"] }] },
    tainted_bimbim: { name: "Bim Bim Nhiễm Bẩn", icon: "🖤", usable: ["combat", "map"], target: "self", price: null, taintedPrice: 3, special: true,
               desc: "Hồi 60% HP tối đa và +30 Nộ.",
               effects: [{ type: "healPct", pct: 0.60 }, { type: "rage", amount: 30 }] },
    tainted_core:    { name: "Lõi Hận Thù", icon: "🔮", usable: ["combat"], target: "self", price: null, taintedPrice: 6, special: true,
               desc: "Lập tức đầy thanh Nộ (Ultimate sẵn sàng).",
               effects: [{ type: "rage", amount: 100 }] },
    tainted_shroud:  { name: "Áo Choàng Vấy Bẩn", icon: "🧥", usable: ["combat"], target: "self", price: null, taintedPrice: 5, special: true,
               desc: "+45 DEF và +20 ATK trong 3 turn.",
               effects: [{ type: "buff", stat: "def", amount: 45, turns: 3 }, { type: "buff", stat: "atk", amount: 20, turns: 3 }] },
    armor:   { name: "Áo giáp bìa carton", icon: "📦", usable: ["combat"], target: "self", price: null,
               desc: "+20 DEF trong 3 turn.",
               effects: [{ type: "buff", stat: "def", amount: 20, turns: 3 }] }
  };
  const RELICS = {
    lapeace: { name: "Mảnh La Peace", icon: "💠" }
  };
  /* Mỗi loại Mảnh La Peace = 1 sức mạnh đặc biệt cho người nắm giữ (người chơi lẫn NPC). Mỗi loại chỉ có 1 mảnh. */
  const LAPEACE_ORDER = ["spellBreaker", "manaTransfer", "dieTwice"];
  const LAPEACE_PIECES = {
    spellBreaker: { id: "spellBreaker", name: "Spell Breaker", icon: "✦",
      desc: "Khi kẻ địch tung ULTIMATE lên bạn sẽ hiện QTE parry: bấm đúng để phá giải hoàn toàn đòn đó." },
    manaTransfer: { id: "manaTransfer", name: "Mana Transfer", icon: "🔷",
      desc: "Sau mỗi lần tung ULTIMATE, bạn được hồi lại 50% thanh Nộ." },
    dieTwice:     { id: "dieTwice", name: "Die Twice", icon: "♻️",
      desc: "Sau khi chết lần đầu trong một trận, bạn hồi sinh với 50% HP tối đa." }
  };
  const COMPONENTS = {
    pin:  { name: "Pin cũ", icon: "🔋" },
    wire: { name: "Dây điện", icon: "🔌" },
    tape: { name: "Băng keo", icon: "🧷" },
    pipe: { name: "Ống thép", icon: "🔧" }
  };
  const RECIPES = {
    grenade: { pin: 2, pipe: 1 },
    flash:   { pin: 1, wire: 1 },
    trap:    { wire: 1, tape: 1 },
    armor:   { tape: 2, pipe: 1 },
    camera:  { wire: 2, tape: 1 }
  };

  /* ============================ 5) DANH SÁCH NHÂN VẬT ============================ */
  const DEFAULT_PLAYER_NAME = "Tôi Yêu UIT";
  // legacyKey: khoá cũ trong script.js (S.npc.B / S.npc.E) để dễ nối code về sau
  const NPC_ROSTER = [
    { id: "WIBU",  legacyKey: "E", name: "Wibu Việt Nhật",      title: "Lolicon", homeRoom: "E" },
    { id: "LINH",  legacyKey: "B", name: "Chàng Lính Ngu Lam",  title: "Quỷ Vương Bất Tử",  homeRoom: "B" },
    { id: "TRONG", legacyKey: null, name: "Trọng",              title: "Người Hoa Hòe",     homeRoom: "C" },
    { id: "TOBY",  legacyKey: null, name: "Toby",               title: "Sinh viên ngoại quốc, hay cúp tiết, luôn dắt theo một con chó phiền phức", homeRoom: "A" }
  ];

  /* ============================ HELPERS ============================ */
  let rng = Math.random;
  function setRng(fn) { rng = fn || Math.random; }
  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  let state = null; // { fighters:{id:f}, order:[ids], night:0, chapter:1 }

  /* ============================ FIGHTER / STATS ============================ */
  function getStats(f) {
    if (f.statsOverride) return Object.assign({}, f.statsOverride);   // The TIU
    const b = CLASSES[f.classId].base;
    let mult = 1;
    CFG.GROWTH_LEVELS.forEach(function (lv) { if (f.level >= lv) mult += CFG.GROWTH_PCT; });
    return {
      hp: Math.round(b.hp * mult), atk: Math.round(b.atk * mult),
      def: Math.round(b.def * mult), spd: Math.round(b.spd * mult)
    };
  }

  function createFighter(o) {
    const f = {
      id: o.id, name: o.name, title: o.title || "", isPlayer: !!o.isPlayer,
      legacyKey: o.legacyKey || null, classId: o.classId, homeRoom: o.homeRoom || null,
      level: 1, exp: 0, hp: 0, maxHp: 0, rage: 0, pieces: [], laPeace: 0, spellBreaker: false,
      drl: CFG.START_DRL, trust: 0, inParty: false, alive: true,
      items: {}, components: {}, statuses: []
    };
    f.maxHp = getStats(f).hp;
    f.hp = f.maxHp;
    return f;
  }

  /* ============================ SKILL ============================ */
  function allClassSkills() {
    const out = [];
    CLASS_IDS.forEach(function (cid) { CLASSES[cid].skills.forEach(function (s) { out.push(s); }); });
    return out;
  }
  function getSkills(f) {
    if (f.tiu) return allClassSkills().map(function (s) { return Object.assign({ cd: CFG.SKILL_CD[s.lvl], unlocked: true }, s); });
    const c = CLASSES[f.classId];
    return c.skills.map(function (s) {
      return Object.assign({ cd: CFG.SKILL_CD[s.lvl], unlocked: f.level >= s.lvl }, s);
    });
  }
  function getUltimate(f) {
    if (f.tiu) {   // TIU xoay vòng Ultimate của cả 5 class
      const list = CLASS_IDS.map(function (cid) { return CLASSES[cid].ultimate; });
      return Object.assign({ unlocked: true, rageCost: CFG.RAGE_MAX }, list[(f.ultIdx || 0) % list.length]);
    }
    const u = CLASSES[f.classId].ultimate;
    return Object.assign({ unlocked: f.level >= CFG.ULT_UNLOCK_LEVEL, rageCost: CFG.RAGE_MAX }, u);
  }
  function addRage(f, n) {
    f.rage = Math.max(0, Math.min(CFG.RAGE_MAX, f.rage + n));
    return f.rage;
  }
  const rageOnAttack = function (f) { return addRage(f, CFG.RAGE_ON_ATTACK); };
  const rageOnSkill  = function (f) { return addRage(f, CFG.RAGE_ON_SKILL); };
  function canUseUltimate(f) { return f.level >= CFG.ULT_UNLOCK_LEVEL && f.rage >= CFG.RAGE_MAX; }

  /* ============================ HP NGOÀI TRẬN (HP được giữ lại giữa các trận) ============================ */
  function heal(f, amount) {
    if (!f.alive) return 0;
    const h = Math.max(0, Math.min(f.maxHp - f.hp, Math.round(amount)));
    f.hp += h;
    return h;
  }
  function healPct(f, pct) { return heal(f, f.maxHp * pct); }
  /* Hồi dần theo thời gian: cộng dồn phần lẻ để không mất khi amount < 1 */
  function regen(f, amount) {
    if (!f.alive || f.hp >= f.maxHp) { f._acc = 0; return 0; }
    f._acc = (f._acc || 0) + amount;
    const whole = Math.floor(f._acc);
    if (whole <= 0) return 0;
    f._acc -= whole;
    return heal(f, whole);
  }
  function healAll() {
    state.order.forEach(function (id) { const f = state.fighters[id]; if (f.alive) { f.hp = f.maxHp; f._acc = 0; } });
  }

  /* ============================ EXP / LEVEL ============================ */
  function expToNext(f) {
    return f.level >= CFG.MAX_LEVEL ? 0 : CFG.EXP_TABLE[f.level + 1] - f.exp;
  }
  function expForWin(winner, loser) {
    let exp = CFG.EXP_BASE_WIN + CFG.EXP_PER_ENEMY_LEVEL * loser.level;
    if (loser.level > winner.level) exp = Math.round(exp * (1 + CFG.EXP_UNDERDOG_BONUS));
    return exp;
  }
  /* Trả về {gained, levelsGained:[lv...], unlocked:[{lvl,name,isUltimate}], newLevel} */
  function addExp(f, amount) {
    const res = { gained: 0, levelsGained: [], unlocked: [], newLevel: f.level };
    if (f.level >= CFG.MAX_LEVEL) return res;
    const before = f.exp;
    f.exp = Math.min(CFG.EXP_TABLE[CFG.MAX_LEVEL], f.exp + Math.max(0, Math.round(amount)));
    res.gained = f.exp - before;
    while (f.level < CFG.MAX_LEVEL && f.exp >= CFG.EXP_TABLE[f.level + 1]) {
      f.level++;
      res.levelsGained.push(f.level);
      const oldMax = f.maxHp;
      f.maxHp = getStats(f).hp;
      if (f.alive) f.hp += f.maxHp - oldMax; // lên cấp: tăng cả máu hiện tại tương ứng
      CLASSES[f.classId].skills.forEach(function (s) {
        if (s.lvl === f.level) res.unlocked.push({ lvl: s.lvl, name: s.name, isUltimate: false });
      });
      if (f.level === CFG.ULT_UNLOCK_LEVEL) {
        res.unlocked.push({ lvl: f.level, name: CLASSES[f.classId].ultimate.name, isUltimate: true });
      }
    }
    res.newLevel = f.level;
    return res;
  }

  /* ============================ ĐRL ============================ */
  /* Kết quả combat giữa 2 người: người thắng cướp 50% ĐRL người thua (người thua mất đúng số đó),
     cộng EXP cho người thắng. Trả về tóm tắt để UI hiển thị. */
  function resolveDuel(winner, loser) {
    const gain = Math.floor(loser.drl * CFG.DRL_STEAL_PCT);                         // người thắng cướp 25%
    const lost = loser.isPlayer ? Math.floor(loser.drl * CFG.DRL_PLAYER_LOSS_PCT) : gain; // người chơi thua: -50%
    loser.drl -= lost;
    winner.drl += gain;
    const exp = addExp(winner, expForWin(winner, loser));
    // Đánh bại kẻ nắm giữ Mảnh La Peace -> lấy hết mảnh của họ (người chơi thua thì KHÔNG bị mất mảnh)
    const pieces = loser.isPlayer ? [] : transferPieces(loser, winner);
    return { winnerId: winner.id, loserId: loser.id, drl: gain, lost: lost, exp: exp, pieces: pieces };
  }
  /* The TIU: hiện thân của TẤT CẢ người từng tham gia — mang đủ skill của mọi class. Mạnh lên theo Lv người chơi. */
  function makeTiu(playerLv) {
    const lv = Math.max(1, playerLv || 1);
    const hp = CFG.TIU_HP_BASE + CFG.TIU_HP_PER_LV * lv;
    return {
      id: "TIU", name: "The TIU", title: "Hiện thân của tất cả", isPlayer: false, tiu: true, classId: "assassin",
      level: 5, exp: 0, hp: hp, maxHp: hp, rage: 0, pieces: [], laPeace: 0, spellBreaker: false,
      drl: 0, trust: 0, inParty: false, alive: true, items: {}, components: {}, statuses: [], ultIdx: 0,
      statsOverride: { hp: hp, atk: CFG.TIU_ATK_BASE + CFG.TIU_ATK_PER_LV * lv,
                       def: CFG.TIU_DEF_BASE + CFG.TIU_DEF_PER_LV * lv, spd: CFG.TIU_SPD }
    };
  }
  function addTainted(f, n) { f.taintedDrl = (f.taintedDrl || 0) + n; f.taintedEver = true; return f.taintedDrl; }
  function tiuPenalty(f, amount) {
    const a = Math.min(f.drl, amount != null ? amount : CFG.TIU_PENALTY);
    f.drl -= a;
    return a;
  }
  function aliveFighters() {
    return state.order.map(function (id) { return state.fighters[id]; }).filter(function (f) { return f.alive; });
  }
  /* Thứ tự từ yếu -> mạnh: ĐRL thấp, rồi EXP thấp, rồi ngẫu nhiên */
  function rankAscending() {
    return shuffle(aliveFighters()).sort(function (a, b) {
      return (a.drl - b.drl) || (a.exp - b.exp);
    });
  }
  /* Cuối đêm Chapter 1: loại người có ĐRL thấp nhất. Người gọi tự xử lý nếu playerEliminated. */
  function eliminateLowest() {
    const list = rankAscending();
    if (list.length <= 2) return null;
    const out = list[0];
    out.alive = false; out.inParty = false;
    const dropped = (out.pieces || []).slice();      // mảnh của người bị loại rơi ra, đêm sau lại có thể xuất hiện
    out.pieces = []; syncPieces(out);
    return { eliminated: out, playerEliminated: out.isPlayer, remaining: aliveFighters().length, droppedPieces: dropped };
  }

  /* ============================ CÂN BẰNG CẤP ĐỘ ĐỐI THỦ ============================ */
  /* Nâng Lv lên `lv` (không bao giờ hạ). Chỉ số/HP tính lại theo Lv mới, giữ nguyên tỉ lệ HP hiện tại. */
  function setLevel(f, lv) {
    lv = Math.min(CFG.MAX_LEVEL, lv);
    if (lv <= f.level) return false;
    const ratio = f.maxHp > 0 ? f.hp / f.maxHp : 1;
    f.level = lv;
    f.exp = Math.max(f.exp, CFG.EXP_TABLE[lv]);
    f.maxHp = getStats(f).hp;
    f.hp = Math.max(1, Math.round(f.maxHp * ratio));
    return true;
  }
  /* Mọi đối thủ còn sống (không phải đồng đội) được nâng lên ít nhất = max(mốc theo đêm, Lv người chơi). Trả về danh sách đối thủ vừa được nâng. */
  function scaleOpponents(floorLv) {
    const me = state.fighters.PLAYER;
    const target = Math.min(CFG.MAX_LEVEL, Math.max(floorLv || 1, me.level));
    return aliveFighters().filter(function (f) {
      return !f.isPlayer && !f.inParty && setLevel(f, target);
    });
  }

  /* ============================ LA PEACE (3 loại mảnh, mỗi loại 1 sức mạnh) ============================ */
  /* f.pieces = danh sách loại mảnh đang giữ. f.laPeace (số mảnh) và f.spellBreaker (bool) được đồng bộ để code cũ vẫn chạy. */
  function syncPieces(f) {
    f.pieces = f.pieces || [];
    f.laPeace = f.pieces.length;
    f.spellBreaker = f.pieces.indexOf("spellBreaker") >= 0;
  }
  function hasPiece(f, type) { return !!(f && f.pieces && f.pieces.indexOf(type) >= 0); }
  /* Người còn sống đang giữ loại mảnh này (hoặc null) */
  function pieceOwner(type) {
    return aliveFighters().filter(function (f) { return hasPiece(f, type); })[0] || null;
  }
  /* Các loại mảnh chưa ai (còn sống) nắm giữ -> có thể xuất hiện trên bản đồ */
  function unownedPieces() {
    return LAPEACE_ORDER.filter(function (t) { return !pieceOwner(t); });
  }
  /* Nhặt 1 Mảnh La Peace loại `type` (bỏ trống = loại chưa ai giữ đầu tiên).
     Trả về {count, type, unlocked}: unlocked=true nếu thực sự nhận thêm sức mạnh mới. */
  function addLaPeace(f, type) {
    f.pieces = f.pieces || [];
    if (!type) type = unownedPieces()[0];
    if (!type || !LAPEACE_PIECES[type] || hasPiece(f, type)) { syncPieces(f); return { count: f.pieces.length, type: type || null, unlocked: false }; }
    f.pieces.push(type);
    syncPieces(f);
    return { count: f.pieces.length, type: type, unlocked: true };
  }
  /* Người thắng lấy toàn bộ mảnh của người thua. Trả về mảng loại mảnh vừa chuyển. */
  function transferPieces(from, to) {
    const moved = (from.pieces || []).filter(function (t) { return !hasPiece(to, t); });
    from.pieces = (from.pieces || []).filter(function (t) { return moved.indexOf(t) < 0; });
    to.pieces = (to.pieces || []).concat(moved);
    syncPieces(from); syncPieces(to);
    return moved;
  }
  /* Mảnh không ai nhặt trước 03:00 -> 1 đối thủ ngẫu nhiên nhận (ưu tiên đối thủ chưa vào đội người chơi). Trả về fighter nhận. */
  function giveToRandomOpponent(type) {
    let pool = aliveFighters().filter(function (f) { return !f.isPlayer && !f.inParty; });
    if (!pool.length) pool = aliveFighters().filter(function (f) { return !f.isPlayer; });
    if (!pool.length) return null;
    const f = pool[Math.floor(rng() * pool.length)];
    addLaPeace(f, type);
    return f;
  }

  /* ============================ TRUST / PARTY ============================ */
  function talk(npc) {
    npc.trust = Math.min(CFG.TRUST_MAX, npc.trust + 1);
    return npc.trust;
  }
  function partyAllies() {
    return aliveFighters().filter(function (f) { return !f.isPlayer && f.inParty; });
  }
  function canRecruit(npc) {
    if (!npc.alive || npc.isPlayer) return { ok: false, reason: "invalid" };
    if (npc.inParty) return { ok: false, reason: "already" };
    if (npc.trust < CFG.RECRUIT_TRUST) return { ok: false, reason: "trust" };
    if (partyAllies().length >= CFG.PARTY_MAX_ALLIES) return { ok: false, reason: "full" };
    return { ok: true };
  }
  function recruit(npc) {
    const chk = canRecruit(npc);
    if (chk.ok) npc.inParty = true;
    return chk;
  }
  function dismiss(npc) { npc.inParty = false; }

  /* ============================ KHO ĐỒ / CHẾ TẠO ============================ */
  function countItem(f, id) { return f.items[id] || 0; }
  function addItem(f, id, n) { f.items[id] = (f.items[id] || 0) + (n == null ? 1 : n); return f.items[id]; }
  function removeItem(f, id, n) {
    n = n == null ? 1 : n;
    if (countItem(f, id) < n) return false;
    f.items[id] -= n;
    if (f.items[id] <= 0) delete f.items[id];
    return true;
  }
  function addComponent(f, id, n) { f.components[id] = (f.components[id] || 0) + (n == null ? 1 : n); }
  function canCraft(f, itemId) {
    const r = RECIPES[itemId];
    if (!r) return false;
    return Object.keys(r).every(function (k) { return (f.components[k] || 0) >= r[k]; });
  }
  function craft(f, itemId) {
    if (!canCraft(f, itemId)) return false;
    const r = RECIPES[itemId];
    Object.keys(r).forEach(function (k) { f.components[k] -= r[k]; });
    addItem(f, itemId, 1);
    return true;
  }
  /* Thắng NPC -> cướp 1 vật phẩm ngẫu nhiên (nếu có) */
  function lootRandomItem(from, to) {
    const keys = Object.keys(from.items).filter(function (k) { return from.items[k] > 0; });
    if (!keys.length) return null;
    const id = keys[Math.floor(rng() * keys.length)];
    removeItem(from, id, 1);
    addItem(to, id, 1);
    return id;
  }

  /* ============================ MÔ PHỎNG NPC ĐÁNH NHAU NGẦM ============================ */
  function power(f) {
    const s = getStats(f);
    return (s.atk * 2 + s.def + s.spd + s.hp / 2 + f.level * 10) * (0.85 + rng() * 0.3);
  }
  function simulateDuel(a, b) {
    const w = power(a) >= power(b) ? a : b;
    const l = w === a ? b : a;
    const r = resolveDuel(w, l);
    lootRandomItem(l, w);
    return r;
  }
  /* Mỗi đêm: các NPC còn sống, không ở trong đội người chơi, bắt cặp ngẫu nhiên đánh nhau */
  function simulateNpcNight() {
    const pool = shuffle(aliveFighters().filter(function (f) { return !f.isPlayer && !f.inParty; }));
    const out = [];
    for (let i = 0; i + 1 < pool.length; i += 2) out.push(simulateDuel(pool[i], pool[i + 1]));
    return out;
  }

  /* ============================ KHỞI TẠO / LƯU ============================ */
  function scoreQuiz(answers) {
    // answers: mảng các classId đã chọn (mỗi câu 1 đáp án) -> classId nhiều điểm nhất, hoà thì ngẫu nhiên
    const score = {};
    CLASS_IDS.forEach(function (c) { score[c] = 0; });
    answers.forEach(function (c) { if (score[c] != null) score[c]++; });
    const max = Math.max.apply(null, CLASS_IDS.map(function (c) { return score[c]; }));
    const top = CLASS_IDS.filter(function (c) { return score[c] === max; });
    return top[Math.floor(rng() * top.length)];
  }

  function init(opts) {
    opts = opts || {};
    if (opts.rng) setRng(opts.rng);
    const playerClass = opts.playerClass || CLASS_IDS[Math.floor(rng() * CLASS_IDS.length)];
    const rest = shuffle(CLASS_IDS.filter(function (c) { return c !== playerClass; }));
    state = { fighters: {}, order: [], night: 0, chapter: 1 };
    const name = (opts.playerName || "").trim() || DEFAULT_PLAYER_NAME;
    const player = createFighter({ id: "PLAYER", name: name, isPlayer: true, classId: playerClass });
    state.fighters.PLAYER = player; state.order.push("PLAYER");
    NPC_ROSTER.forEach(function (n, i) {
      const f = createFighter({ id: n.id, name: n.name, title: n.title, legacyKey: n.legacyKey,
                                homeRoom: n.homeRoom, classId: rest[i] });
      state.fighters[n.id] = f; state.order.push(n.id);
    });
    // Khởi đầu: mỗi người có sẵn 1 Bim Bim (giống inventory cũ)
    state.order.forEach(function (id) { addItem(state.fighters[id], "bimbim", 1); });
    return state;
  }
  const get = function (id) { return state.fighters[id]; };
  const player = function () { return state.fighters.PLAYER; };
  const getState = function () { return state; };
  const serialize = function () { return state ? JSON.parse(JSON.stringify(state)) : null; };
  const load = function (data) {
    state = data ? JSON.parse(JSON.stringify(data)) : null;
    if (state) Object.keys(state.fighters).forEach(function (id) {   // tương thích save cũ (chỉ có bộ đếm laPeace)
      const f = state.fighters[id];
      if (!f.pieces) { f.pieces = []; for (let i = 0; i < (f.laPeace || 0) && i < LAPEACE_ORDER.length; i++) f.pieces.push(LAPEACE_ORDER[i]); }
      syncPieces(f);
    });
    return state;
  };

  /* ============================ XUẤT RA NGOÀI ============================ */
  const RPG = {
    CFG: CFG, CLASSES: CLASSES, CLASS_IDS: CLASS_IDS, CLASS_QUIZ: CLASS_QUIZ,
    ITEMS: ITEMS, RELICS: RELICS, LAPEACE_PIECES: LAPEACE_PIECES, LAPEACE_ORDER: LAPEACE_ORDER, COMPONENTS: COMPONENTS, RECIPES: RECIPES, NPC_ROSTER: NPC_ROSTER,
    DEFAULT_PLAYER_NAME: DEFAULT_PLAYER_NAME,
    setRng: setRng, scoreQuiz: scoreQuiz, init: init, get: get, player: player,
    getState: getState, serialize: serialize, load: load,
    getStats: getStats, getSkills: getSkills, getUltimate: getUltimate,
    addRage: addRage, rageOnAttack: rageOnAttack, rageOnSkill: rageOnSkill, canUseUltimate: canUseUltimate,
    heal: heal, healPct: healPct, regen: regen, healAll: healAll,
    expToNext: expToNext, expForWin: expForWin, addExp: addExp,
    resolveDuel: resolveDuel, setLevel: setLevel, scaleOpponents: scaleOpponents, tiuPenalty: tiuPenalty, makeTiu: makeTiu, ELEMENTS: ELEMENTS, SKILL_ELEMENT: SKILL_ELEMENT, affinityOf: affinityOf, basicElement: basicElement, elementLabel: elementLabel, addTainted: addTainted, aliveFighters: aliveFighters,
    rankAscending: rankAscending, eliminateLowest: eliminateLowest,
    addLaPeace: addLaPeace, hasPiece: hasPiece, pieceOwner: pieceOwner, unownedPieces: unownedPieces,
    transferPieces: transferPieces, giveToRandomOpponent: giveToRandomOpponent, syncPieces: syncPieces,
    talk: talk, partyAllies: partyAllies, canRecruit: canRecruit, recruit: recruit, dismiss: dismiss,
    countItem: countItem, addItem: addItem, removeItem: removeItem, addComponent: addComponent,
    canCraft: canCraft, craft: craft, lootRandomItem: lootRandomItem,
    simulateDuel: simulateDuel, simulateNpcNight: simulateNpcNight
  };
  global.RPG = RPG;
  if (typeof module !== "undefined" && module.exports) module.exports = RPG;
})(typeof window !== "undefined" ? window : globalThis);